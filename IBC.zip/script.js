document.querySelector('.upload-btn').addEventListener('click', function() {
    alert('Upload button clicked');
    // Implement the upload functionality here
});

document.querySelector('.camera-btn').addEventListener('click', function() {
    alert('Camera button clicked');
    // Implement the camera functionality here
});

document.querySelector('.next-btn').addEventListener('click', function() {
    alert('Proceed to Step 2');
    // Redirect or display the next step of the verification process
});
function showStep(stepToShow) {
    let steps = document.querySelectorAll('.step');
    steps.forEach(step => step.classList.remove('active'));
    document.getElementById(stepToShow).classList.add('active');
}

document.getElementById('go-to-step-2').addEventListener('click', function() {
    showStep('step-2');
});

document.getElementById('go-to-step-1').addEventListener('click', function() {
    showStep('step-1');
});
